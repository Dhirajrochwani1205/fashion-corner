
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>All Producrs - Fashion Connect</title>
    <link rel="stylesheet" href="style.css" />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    />
    <link
      rel="stylesheet"
      href="https://unicons.iconscout.com/release/v4.0.8/css/line.css"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    />
    <link rel="Fashion Connect" type="png" href="images/logo.png" />
  </head>
  <body>
    <!-- Page loader container -->
    <div class="loader-container" id="loader">
      <div class="loader"></div>
    </div>
    <div class="container" style="background-image: url(images/pexels-pixabay-52518.jpg);">
      <div class="navbar">
        <div class="logo">
          <a href=""><img src="images/Fashion Clothes Logo/1.png" width="200px" /></a>
        </div>
        <div class="search-box">
          <div class="search-box2">
            <input type="text"id="input-box" placeholder="search anything" autocomplete="off">
            <button><i class="fa-solid fa-magnifying-glass"></i></button>
          </div>
          <div class="result-box">
            
          </div>
        </div>
        <nav>
          <ul id="MenuItems">
            <li><a href="index.html">Home</a></li>
            <li><a href="product.html">Product</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="account.html">Account</a></li>
          </ul>
        </nav>
        <a href="cart.html"
            ><i class="fa-solid fa-cart-shopping" width ="20px" heigth ="20px"></i>
          </a>
        <img src="images/menu.png" class="menu-icon" onclick="menutoggle()" />
      </div>
    </div>
    <!-- ---------------account-page-------- -->
    <div class="account-page">
      <div class="container">
        <div class="row">
          <div class="col-2">
            <img src="images/shirt.png" width="100%" />
          </div>
          <div class="col-2">
            <div class="form-container">
              <div class="form-btn">
                <span onclick="login()">Login</span>
                <span onclick="register()">Register</span>
                <hr id="Indicator" />
              </div>
              <form id="Loginform">
                <input type="text" placeholder="Username" required/>
                <input type="password" placeholder="Password" required />
                <button type="submit" class="btn">Login</button>
                <a href="">Forgot password</a>
                <p>Don't have please Register First</p>
              </form>
              <form id="Regform">
                <input type="text" placeholder="fullname" required/>
                <input type="email" placeholder="email" required/>
                <input type="password" placeholder="password" required/>
                <input type="password" placeholder="confirm_password">
                <button type="submit" class="btn" name="submit">Register</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- ---------Footer--------- -->
    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="footer-col-1">
            <h3>Download Our App</h3>
            <p>Download App For Android and Ios mobile phone.</p>
            <div class="app-logo">
              <img src="images/play-store.png" />
              <img src="images/app-store.png" />
            </div>
          </div>
          <div class="footer-col-2">
            <img src="images/Fashion Clothes Logo/1.png" />
            <p>
              Our Purpose Is To Sustainably Make the Pleasure and Benefites of
              Sports Accessfible to the Many .
            </p>
          </div>
          <div class="footer-col-3">
            <h3>Useful Link</h3>
            <ul>
              <li>Coupons</li>
              <li>Blog Post</li>
              <li>Return Policy</li>
              <li>Join Affilate</li>
            </ul>
          </div>
          <div class="footer-col-4">
            <h3>Follow us</h3>
            <ul>
              <li>Facebook</li>
              <li>Twitter</li>
              <li>Instagram</li>
              <li>Youtube</li>
            </ul>
          </div>
        </div>
        <hr />
        <p class="copyright">Copyright 2020 - PDP</p>
      </div>
    </div>
    <!-- -----------js for toggle menu------------- -->
    <script>
      var MenuItems = document.getElementById("MenuItems");
      MenuItems.style.maxHeight = "0px";
      function menutoggle() {
        if (MenuItems.style.maxHeight == "0px") {
          MenuItems.style.maxHeight = "2000px";
        } else {
          MenuItems.style.maxHeight = "0px";
        }
      }
    </script>
    <!-- ---------------js for login form-------------- -->
    <script>
      var Loginform =document.getElementById("Loginform");
      var Regform =document.getElementById("Regform");
      var Indicator =document.getElementById("Incicator");
      function register(){
        Regform.style.transform = "translateX(0px)";
        Loginform.style.transform = "translateX(0px)";
        Indicator.style.transform = "translateX(100px)";
      }
      function login(){
        Regform.style.transform = "translateX(300px)";
        Loginform.style.transform = "translateX(300px)";
        Indicator.style.transform = "translateX(0px)";
      }
      // Simulate an AJAX request (you can replace this with an actual AJAX call)
      setTimeout(function () {
        // Hide the loader and display the content
        document.getElementById("loader").style.display = "none";
        document.getElementById("content").classList.remove("loaded");
      }, 3000); // Simulated delay of 3 seconds
    </script>
    <script src="autocomplete.js"></script>
  </body>
</html>
