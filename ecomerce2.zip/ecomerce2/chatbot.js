const chatButton = document.getElementById('chatButton');
const chatContainer = document.getElementById('chatContainer');
const chatMessages = document.getElementById('chatMessages');
const userInput = document.getElementById('userInput');
const sendButton = document.getElementById('sendButton');

chatButton.addEventListener('click', () => {
  chatContainer.style.display = 'block';
  chatButton.style.display = 'none';
});

sendButton.addEventListener('click', sendMessage);
userInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    sendMessage();
    event.preventDefault();
  }
});

function sendMessage() {
  const message = userInput.value.trim();
  if (message !== '') {
    appendMessage('user', message);

    let chatbotResponse = generateChatbotResponse(message);

    appendMessage('chatbot', chatbotResponse);

    userInput.value = '';
  }
}

function generateChatbotResponse(userMessage) {
  if (userMessage.toLowerCase().includes('hii') ||userMessage.toLowerCase().includes('hi') || userMessage.toLowerCase().includes('hello') || userMessage.toLowerCase().includes('hy') || userMessage.toLowerCase().includes('hyy')) {
    return 'Hello! How can I help you?';
  } else if (userMessage.toLowerCase().includes('offers') || userMessage.toLowerCase().includes('discounts') || userMessage.toLowerCase().includes('discount')) {
    return 'Sure! Here are the products listed with discounted prices:\n1. Product A: $50 (was $70)\n2. Product B: $30 (was $40)';
  } else if (userMessage.toLowerCase().includes('payment') || userMessage.toLowerCase().includes(' payment option')) {
    return 'Currently, we only offer Cash on Delivery as a payment option.';
  } else if (userMessage.toLowerCase().includes('product') || userMessage.toLowerCase().includes('products')) {
    return 'We have variety of products on our site, check it out by clickin products page.';
  } else if (userMessage.toLowerCase().includes('bye') || userMessage.toLowerCase().includes('goodbye')){
    return 'GoodBye!!Have a Nice Day.!'
  } else if (userMessage.toLowerCase().includes('ok')){
    return 'Feel Free to ask Anything else!!'
  }
   else {
    return "Sorry, I didn't understand. Could you please rephrase it?";
  }
}

function appendMessage(sender, message) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', sender);
  messageElement.textContent = message;
  chatMessages.appendChild(messageElement);
}
const closeButton = document.getElementById('closeButton');

//function to close chatbot
function closeChatbot() {
    chatContainer.style.display='none';
    chatButton.style.display='block';
}